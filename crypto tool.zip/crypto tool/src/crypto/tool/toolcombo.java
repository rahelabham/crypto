package crypto.tool;

import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jimmy bham
 */
public class toolcombo {
    public String sample;
        private int option;
          public toolcombo(int option) {
        if(option == 1)
        {
           
            this.shift();
            this.Poly();
            this.Hill();
            this.PlayfairCipher();
            this.column();
            this.Rail();
            this.MonoalphabeticCipher();
          this.RSA();
        }
        else
        {System.out.println("\nError");
        }
        
        
}

    private void Poly() {
System.out.println("\n2. PolyCipher Massage Exchange\n");
throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void shift() {
System.out.println("\n1. ShiftCipher Massage Exchange\n");
throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void Hill() {
        System.out.println("\n3. HillCipher Massage Exchange\n");
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void column() {
        System.out.println("\n5. columnCipher Massage Exchange\n");
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void PlayfairCipher() {
         System.out.println("\n4. PlayfairCipher Massage Exchange\n");
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void Rail() {
System.out.println("\n6. RailCipher Massage Exchange\n");
throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void MonoalphabeticCipher() {
System.out.println("\n7. MonoalphabeticCipher Massage Exchange\n");
throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void RSA() {
System.out.println("\n8. RSA Massage Exchange\n");
throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
     public static void main(String[] args)
    {
        try (Scanner sc = new Scanner(System.in)) 
        {
            System.out.println("Enter the no1 for Shift");
            System.out.println("Enter the no2 for Poly");
            System.out.println("Enter the no3 for Column");
            System.out.println("Enter the no4 for Playfair");
            System.out.println("Enter the no5 for Rail");
            System.out.println("Enter the no6 for Mono");
            System.out.println("Enter the no7 for RSA");
            
            System.out.println("Enter the no : ");
            String message = new String();
            
            
        }
}
}